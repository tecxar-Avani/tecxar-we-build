export interface IBoxesGroups {
    id: number;
    box_id: number;
    group_id: number
}
export interface IUpdateBoxesGroups {
    id?: number;
    box_id?: number;
    group_id?: number
}