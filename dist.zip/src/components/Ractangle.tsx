import React from "react";

const Ractangle = (props: any) => {
  return <div className="h-30 border border-color-25"></div>;
};

export default Ractangle;
